import "./globals.css";

export const metadata = {
  title: "Envoserve Infra Developers",
  description: "Investing in Nature. Empowering Sustainable Futures."
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}