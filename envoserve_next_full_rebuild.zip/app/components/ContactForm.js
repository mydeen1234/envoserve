"use client";

import { useState } from "react";

export default function ContactForm() {
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitting(true);

    // Placeholder: integrate API / backend here
    setTimeout(() => {
      alert("Your enquiry was sent successfully!");
      setSubmitting(false);
    }, 600);
  };

  return (
    <form className="contact__form" onSubmit={handleSubmit}>
      <div className="field">
        <label htmlFor="name">Name</label>
        <input id="name" placeholder="Your name" />
      </div>
      <div className="field">
        <label htmlFor="email">Email</label>
        <input id="email" type="email" placeholder="you@example.com" />
      </div>
      <div className="field">
        <label htmlFor="message">Message</label>
        <textarea
          id="message"
          rows={4}
          placeholder="Share your farmland or investment requirement..."
        />
      </div>
      <button className="btn btn--primary" type="submit" disabled={submitting}>
        {submitting ? "Submitting..." : "Submit Enquiry"}
      </button>
    </form>
  );
}