import ContactForm from "./components/ContactForm";

function Section({ id, title, children, muted }) {
  return (
    <section
      id={id}
      className={`section ${muted ? "section--muted" : ""}`}
    >
      <div className="container">
        {title && <h2 className="section__title">{title}</h2>}
        {children}
      </div>
    </section>
  );
}

function Hero() {
  return (
    <header className="hero" id="top">
      <nav className="nav">
        <div className="nav__inner container">
          <div className="nav__logo">
            <span className="nav__logo-mark">E</span>
            <span className="nav__logo-text">Envoserve Infra Developers</span>
          </div>
          <div className="nav__links">
            <a href="#about">About</a>
            <a href="#services">Services</a>
            <a href="#projects">Projects</a>
            <a href="#technology">Technology</a>
            <a href="#sustainability">Sustainability</a>
            <a href="#invest">Why Invest</a>
            <a href="#contact">Contact</a>
          </div>
        </div>
      </nav>

      <div className="hero__content container">
        <div className="hero__text">
          <p className="hero__eyebrow">
            Investing in Nature. Empowering Sustainable Futures.
          </p>
          <h1 className="hero__title">
            Nature-first <span>farmland ecosystems</span> for long-term value.
          </h1>
          <p className="hero__subtitle">
            Envoserve Infra Developers specializes in integrated farmland
            development that protects the environment, empowers farmers, supports
            landowners, and generates sustainable revenue across Tamil Nadu.
          </p>
          <div className="hero__actions">
            <a href="#invest" className="btn btn--primary">
              Explore Investment Models
            </a>
            <a href="#contact" className="btn btn--ghost">
              Talk to Our Team
            </a>
          </div>
        </div>
        <div className="hero__media">
          <div className="hero__image hero__image--main" />
          <div className="hero__image hero__image--secondary" />
        </div>
      </div>
    </header>
  );
}

function About() {
  return (
    <Section id="about" title="About Envoserve Infra Developers">
      <div className="grid grid--2">
        <div>
          <p>
            At Envoserve Infra Developers, we believe that nature is the
            foundation of true wealth. Our mission is to create a new-age model
            of farmland development—one that protects the environment, empowers
            farmers, supports landowners, and generates sustainable revenue.
          </p>
          <p>
            We specialize in integrated farmland development at strategic
            locations across Tamil Nadu, combining modern agricultural
            technologies with eco-friendly practices. Every project we build is
            designed to nurture the land, enhance productivity, and help
            communities thrive.
          </p>
        </div>
        <div>
          <h3 className="section__subtitle">Our Story</h3>
          <p>
            Envoserve Infra Developers was founded with the vision of creating
            agricultural ecosystems that enrich both nature and society. With
            increasing demand for organic products and sustainable living
            spaces, we offer integrated farmland projects that serve as
            long-term investments and lifestyle enhancements.
          </p>
          <h3 className="section__subtitle">Our Approach</h3>
          <ul className="list">
            <li>Protecting the environment</li>
            <li>Promoting organic and natural farming techniques</li>
            <li>Creating community-based farming layouts</li>
            <li>Using technology to increase farming efficiency</li>
            <li>Strengthening farmer livelihoods</li>
          </ul>
        </div>
      </div>
    </Section>
  );
}

const coreServices = [
  "Integrated Farmland Development",
  "Smart Drip Irrigation Technology",
  "Zero Budget Natural Farming (ZBNF)",
  "Organic Crop Production",
  "Cattle Rearing & Multi-Layer Farming",
  "Eco-Friendly Farmhouse Development"
];

function Services() {
  return (
    <Section id="services" title="Our Core Services" muted>
      <div className="pill-row">
        {coreServices.map((s) => (
          <span key={s} className="pill">
            {s}
          </span>
        ))}
      </div>

      <div className="grid grid--3 mt-lg">
        <div className="card">
          <h3>Integrated Farmland Development</h3>
          <p>
            End-to-end development including layout design, soil testing, water
            planning, land preparation, plantations, and eco-infrastructure.
          </p>
        </div>
        <div className="card">
          <h3>Smart Drip Irrigation</h3>
          <p>
            Advanced automated drip irrigation systems that optimize water use,
            reduce labour, and improve crop health and yields.
          </p>
        </div>
        <div className="card">
          <h3>Revenue-Generative Farm Models</h3>
          <p>
            Structured farming models that generate consistent income through
            organic produce, livestock, multi-layer farming and agro-tourism.
          </p>
        </div>
        <div className="card">
          <h3>Zero Budget Natural Farming (ZBNF)</h3>
          <p>
            Chemical-free farming using natural fertilizers, mulching,
            cow-based inputs and regenerative soil practices.
          </p>
        </div>
        <div className="card">
          <h3>Organic Crop Production</h3>
          <p>
            Cultivation of high-demand organic fruits, vegetables, greens and
            herbs for health-conscious markets.
          </p>
        </div>
        <div className="card">
          <h3>Eco-Friendly Farmhouse Development</h3>
          <p>
            Comfortable, eco-friendly farmhouses in secure gated farmland
            communities ideal for weekend retreats and nature-first living.
          </p>
        </div>
      </div>
    </Section>
  );
}

function Projects() {
  return (
    <Section id="projects" title="Farmland Projects Across Tamil Nadu">
      <div className="grid grid--2">
        <div>
          <p>
            We develop farmland layouts at prime agricultural locations around
            Tamil Nadu. Each project is designed as a self-sustaining,
            future-ready agricultural ecosystem.
          </p>
          <ul className="list">
            <li>Professionally planned farmland layouts</li>
            <li>Smart irrigation and water management systems</li>
            <li>Dedicated organic farming zones</li>
            <li>Cattle and livestock units</li>
            <li>Eco-friendly internal infrastructure</li>
            <li>Farmhouse-ready plots</li>
            <li>Secure, community-focused environments</li>
          </ul>
        </div>
        <div className="card card--image">
          <div className="card__image card__image--projects" />
          <div className="card__body">
            <h3>Integrated Farming Communities</h3>
            <p>
              Designed to balance profitability, sustainability and lifestyle
              for both investors and resident farmers.
            </p>
          </div>
        </div>
      </div>
    </Section>
  );
}

function Technology() {
  return (
    <Section id="technology" title="Farming Technologies">
      <div className="grid grid--2">
        <ul className="list">
          <li>Automated drip irrigation</li>
          <li>Soil health monitoring</li>
          <li>Rainwater harvesting systems</li>
          <li>Zero Budget Natural Farming inputs</li>
          <li>Smart water management and storage</li>
        </ul>
        <div className="card card--image">
          <div className="card__image card__image--technology" />
          <div className="card__body">
            <h3>Tech-Enabled Farmland</h3>
            <p>
              We combine traditional wisdom with modern agri-tech to build
              efficient, resilient farming systems.
            </p>
          </div>
        </div>
      </div>
    </Section>
  );
}

function Sustainability() {
  return (
    <Section
      id="sustainability"
      title="Sustainability & Environmental Commitment"
      muted
    >
      <div className="grid grid--2">
        <div>
          <p>
            Sustainability is at the heart of everything we do. Our projects are
            planned to minimize disturbance to natural ecosystems while
            improving soil health, water security and biodiversity.
          </p>
          <ul className="list">
            <li>Zero chemical farming practices</li>
            <li>Water conservation and harvesting</li>
            <li>Soil regeneration and carbon-rich farming</li>
            <li>Promotion of native species and biodiversity</li>
            <li>Renewable and circular resource practices</li>
          </ul>
        </div>
        <div className="card card--image">
          <div className="card__image card__image--sustainability" />
          <div className="card__body">
            <h3>Nature-First Design</h3>
            <p>
              Every project is evaluated for long-term ecological impact, not
              just short-term output or returns.
            </p>
          </div>
        </div>
      </div>
    </Section>
  );
}

function Invest() {
  return (
    <Section id="invest" title="Farmland as a Future-Ready Investment">
      <div className="grid grid--2">
        <div>
          <p>
            Farmland is a secure, appreciating asset that can generate
            long-term, inflation-resistant returns. Our integrated models
            combine land appreciation with yearly income from organic farming
            and livestock.
          </p>
          <ul className="list">
            <li>Professionally managed farmland projects</li>
            <li>Transparent development and documentation</li>
            <li>Eco-friendly, community-based layouts</li>
            <li>Structured farm revenue models</li>
            <li>Long-term value appreciation with impact</li>
          </ul>
        </div>
        <div className="card card--image">
          <div className="card__image card__image--invest" />
          <div className="card__body">
            <h3>Investor Support</h3>
            <p>
              From due diligence to ongoing farm management, our team supports
              investors at every stage of ownership.
            </p>
          </div>
        </div>
      </div>
    </Section>
  );
}

function Contact() {
  return (
    <Section id="contact" title="Contact Us" muted>
      <div className="contact">
        <div className="contact__details">
          <h3>Envoserve Infra Developers</h3>
          <p>
            1st Floor, Nila Complex<br />
            Old No: 130B, New No: 30/7<br />
            Bharathi Nagar Bus Stop, Podanur Road<br />
            Coimbatore - 641023, Tamil Nadu, India
          </p>
          <p>
            Phone: <a href="tel:+914224618233">+91 0422 4618233</a>
            <br />
            Email:{" "}
            <a href="mailto:info@envoserve.com">info@envoserve.com</a>
          </p>
        </div>

        {/* Client component form */}
        <ContactForm />
      </div>
    </Section>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__inner">
        <span>© {new Date().getFullYear()} Envoserve Infra Developers</span>
        <span>Investing in Nature. Empowering Sustainable Futures.</span>
      </div>
    </footer>
  );
}

export default function Page() {
  return (
    <>
      <Hero />
      <About />
      <Services />
      <Projects />
      <Technology />
      <Sustainability />
      <Invest />
      <Contact />
      <Footer />
    </>
  );
}